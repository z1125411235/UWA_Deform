﻿namespace Deform
{
	public enum Axis
	{
		X,
		Y,
		Z
	}
}