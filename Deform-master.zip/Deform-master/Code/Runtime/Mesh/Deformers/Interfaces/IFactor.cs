﻿namespace Deform
{
	public interface IFactor
	{
		float Factor { get; set; }
	}
}