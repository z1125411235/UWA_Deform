﻿namespace Deform
{
	public enum ColorChannel
	{
		R = 0,
		G = 1,
		B = 2,
		A = 3
	}
}